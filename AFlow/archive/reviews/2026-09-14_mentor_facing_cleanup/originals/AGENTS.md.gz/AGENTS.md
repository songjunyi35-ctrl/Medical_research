# AFlow repository instructions

These rules apply to every Codex run in this repository and are completion requirements.

## Explain research for a beginner

Assume the user is new to medical image segmentation. Never introduce a method only by acronym, paper, loss, or module name.

Before implementing or launching every new method, first explain in plain Chinese:

1. **现在的问题是什么？** Use current project numbers.
2. **一句话直觉是什么？** Use an everyday analogy when helpful.
3. **为什么现在选它？** Connect the idea to an observed failure/error pattern and primary source; explain why prior negatives do not already disprove it.
4. **具体怎么做？** Explain input→model/teacher→loss/fusion→output in words before formulas.
5. **只改变什么，哪些不变？** Name the single factor and controls.
6. **怎样算成功/失败？** Freeze promotion and stop gates.
7. **代价是什么？** Training time, GPU, disk, inference forwards, deployment complexity.

Expand EMA, KD, TTA, ROI, KL, CE, SAM, etc. on first use. A formula may follow the plain explanation, never replace it.

Write the same explanation before formal execution in the preregistration or `IDEA.md`, using `EXPERIMENT_IDEA_TEMPLATE.md`.

## Canonical method catalog

`AFLOW_BRATS_METHOD_CATALOG.md` is the beginner-readable idea history. Whenever a method is proposed, starts, completes, stops, or changes status, update its entry in the same task.

Each completed card must include status, one-sentence idea, starting problem, procedure, changed/fixed factors, expected mechanism, observed metrics, whether intuition was supported, cost, next decision, and evidence links. Preserve negative ideas and distinguish “this implementation failed” from “the general idea is impossible.”

## Root documentation layout

Do not create new top-level handoff continuations, idea notes, plans, or ad-hoc result Markdown files.

The only allowed root Markdown files are:

- `README.md`
- `AGENTS.md`
- `AFLOW_BRATS_HANDOFF_CURRENT.md`
- `AFLOW_BRATS_HANDOFF_20260813_SINGLE_REPO.md` (historical compatibility)
- `AFLOW_BRATS_LEADERBOARD.md`
- `AFLOW_BRATS_METHOD_CATALOG.md`
- `AFLOW_BRATS_RESULTS.md` (historical compatibility)
- `AFLOW_BRATS_WEEKLY_REPORT.md` (historical compatibility)
- `EXPERIMENT_IDEA_TEMPLATE.md`

New experiment preregistrations/results belong under `archive/research_records/<date>_<method>/`. Staged handoffs, literature notes, or obsolete plans belong under a dated `archive/` directory. Update `AFLOW_BRATS_HANDOFF_CURRENT.md` instead of creating another root continuation.

After moving/adding root documents, run:

```bash
PYTHONDONTWRITEBYTECODE=1 ../sammed3d-venv/bin/python scripts/verify_aflow_brats_doc_layout.py
```

If it fails, documentation cleanup is incomplete.

## Research workflow

1. Read `AFLOW_BRATS_HANDOFF_CURRENT.md`, leaderboard, method catalog, and relevant archived preregistration.
2. Explain the idea with the seven beginner questions before implementation/training.
3. Freeze the plain-language idea/preregistration before formal access.
4. Keep train, validation, outer, confirmation, and test roles explicit. Never call reused test pristine blind or external.
5. Freeze data/checkpoint hashes, grid, threshold, TTA/postprocessing/SAM, output, metrics, bootstrap, selection, and stop gates.
6. Add entry points instead of modifying hash-bound historical scripts. Run focused synthetic tests and proportional GPU smoke.
7. Do not use test to choose loss, weight, epoch, threshold, resolution, checkpoint, ensemble, TTA, or postprocessing unless the user explicitly changes the objective and evidence is labeled test-tuned.
8. Record negatives and implementation failures, including whether checkpoint/validation/test access happened before failure.
9. Check disk before multi-GiB caches. Do not silently delete material data. With authorization, remove raw-rebuildable/hash-archived derived caches while preserving code/checkpoints/reports.
10. After results, explain what happened, whether intuition was supported, why, and what is ruled in/out.

## Mandatory leaderboard update after test

Canonical files:

- `AFLOW_BRATS_LEADERBOARD.md`
- `AFLOW_BRATS_LEADERBOARD.json`

Whenever any method finishes a named test cohort, update both before completion. This includes positive, tied, negative, failed-gate, single, ensemble, oracle, and interactive methods.

Record method/identifier, cohort counts, Scan/Subject Dice, Point hit, checkpoint/ensemble formula, resolution/threshold, forward cost, evidence status, report path/SHA, and reused/test-tuned/external status.

Rules:

1. Never mix validation/outer/confirmation/test in one ranking.
2. Never mix automatic direct locators with GT-centered/oracle/interactive methods in the primary ranking.
3. Sort comparable JSON lists by descending Scan Dice with contiguous ranks; Markdown must match.
4. Label grid/rasterization caveats.
5. Report confidence intervals without turning point-estimate leads into significance.
6. Preserve prior rows and correct provenance explicitly.
7. Update `updated_utc` and validate.

Required command:

```bash
PYTHONDONTWRITEBYTECODE=1 ../sammed3d-venv/bin/python scripts/verify_aflow_brats_leaderboard.py
```

If it fails, the research task is not complete.

## Mandatory result archival

After formal validation/test:

1. Save raw report and pre-access/selection receipt.
2. Recompute checkpoint/report/receipt/cache-index SHA-256.
3. Write `archive/research_records/<date>_<method>/RESULT.md` plus machine JSON.
4. Update `AFLOW_BRATS_HANDOFF_CURRENT.md` with outcome, metrics, access flags, failure boundary, and next decision.
5. Update `AFLOW_BRATS_METHOD_CATALOG.md` with plain result/interpretation.
6. If test ran, update both leaderboard files.
7. Run the method-catalog, leaderboard, and root-layout validators as applicable.

## Final response checklist

State in plain Chinese: idea and motivation; changed/fixed factors; best overall and single-model comparable results; cohort/metric/CI scope; training/inference/storage tradeoff; whether intuition was supported; test/outer/confirmation access; clickable current handoff, catalog, leaderboard, report, archive, and checkpoint.

Do not call a method “best” without naming cohort and overall-versus-single scope.
