# AFlow repository instructions

These rules apply to every Codex run in this repository and are completion requirements.

## Explain research for a beginner

Assume the user is new to medical image segmentation. Never introduce a method only by acronym, paper, loss, or module name.

Before implementing or launching every new method, first explain in plain Chinese:

1. **现在的问题是什么？** Use current project numbers.
2. **一句话直觉是什么？** Use an everyday analogy when helpful.
3. **为什么现在选它？** Connect the idea to an observed failure/error pattern and primary source; explain why prior negatives do not already disprove it.
4. **具体怎么做？** Explain input→model/teacher→loss/fusion→output in words before formulas.
5. **只改变什么，哪些不变？** Name the single factor and controls.
6. **怎样算成功/失败？** Freeze promotion and stop gates.
7. **代价是什么？** Training time, GPU, disk, inference forwards, deployment complexity.

Expand EMA, KD, TTA, ROI, KL, CE, SAM, etc. on first use. A formula may follow the plain explanation, never replace it.

Write the same explanation before formal execution in the preregistration or `IDEA.md`, using `EXPERIMENT_IDEA_TEMPLATE.md`.

## Canonical method catalog

`AFLOW_BRATS_METHOD_CATALOG.md` is the beginner-readable idea history. Whenever a method is proposed, starts, completes, stops, or changes status, update its entry in the same task.

Each completed card must include status, one-sentence idea, starting problem, procedure, changed/fixed factors, expected mechanism, observed metrics, whether intuition was supported, cost, next decision, and evidence links. Preserve negative ideas and distinguish “this implementation failed” from “the general idea is impossible.”

## Root documentation layout

Do not create new top-level handoff continuations, idea notes, plans, or ad-hoc result Markdown files.

The only allowed root Markdown files are:

- `README.md`
- `AGENTS.md`
- `AFLOW_BRATS_HANDOFF_CURRENT.md`
- `AFLOW_BRATS_HANDOFF_20260813_SINGLE_REPO.md` (historical compatibility)
- `AFLOW_BRATS_LEADERBOARD.md`
- `AFLOW_BRATS_METHOD_CATALOG.md`
- `AFLOW_BRATS_RESULTS.md` (active chronological research log)
- `AFLOW_BRATS_WEEKLY_REPORT.md` (mentor-facing research report)
- `EXPERIMENT_IDEA_TEMPLATE.md`

New experiment preregistrations/results belong under `archive/research_records/<date>_<method>/`. Staged handoffs, literature notes, or obsolete plans belong under a dated `archive/` directory. Update `AFLOW_BRATS_HANDOFF_CURRENT.md` instead of creating another root continuation.

After moving/adding root documents, run:

```bash
PYTHONDONTWRITEBYTECODE=1 ../sammed3d-venv/bin/python scripts/verify_aflow_brats_doc_layout.py
```

If it fails, documentation cleanup is incomplete.

## Research workflow

1. Read `AFLOW_BRATS_HANDOFF_CURRENT.md`, leaderboard, method catalog, and relevant archived preregistration.
2. Explain the idea with the seven beginner questions before implementation/training.
3. Freeze the plain-language idea/preregistration before formal access.
4. Keep train, validation, outer, confirmation, and test roles explicit. Never call reused test pristine blind or external.
5. Freeze data/checkpoint hashes, grid, threshold, TTA/postprocessing/SAM, output, metrics, bootstrap, selection, and stop gates.
6. Add entry points instead of modifying hash-bound historical scripts. Run focused synthetic tests and proportional GPU smoke.
7. Do not use test to choose loss, weight, epoch, threshold, resolution, checkpoint, ensemble, TTA, or postprocessing unless the user explicitly changes the objective and evidence is labeled test-tuned.
8. Record negatives and implementation failures, including whether checkpoint/validation/test access happened before failure.
9. Check disk before multi-GiB caches. Do not silently delete material data. With authorization, remove raw-rebuildable/hash-archived derived caches while preserving code/checkpoints/reports.
10. After results, explain what happened, whether intuition was supported, why, and what is ruled in/out.

## Mandatory leaderboard update after test

Canonical files:

- `AFLOW_BRATS_LEADERBOARD.md`
- `AFLOW_BRATS_LEADERBOARD.json`

Whenever any method finishes a named test cohort, update both before completion. This includes positive, tied, negative, failed-gate, single, ensemble, oracle, and interactive methods.

Record method/identifier, cohort counts, Scan/Subject Dice, Point hit, checkpoint/ensemble formula, resolution/threshold, forward cost, evidence status, report path/SHA, and reused/test-tuned/external status.

Rules:

1. Never mix validation/outer/confirmation/test in one ranking.
2. Never mix automatic direct locators with GT-centered/oracle/interactive methods in the primary ranking.
3. Sort comparable JSON lists by descending Scan Dice with contiguous ranks; Markdown must match.
4. Label grid/rasterization caveats.
5. Report confidence intervals without turning point-estimate leads into significance.
6. Preserve prior rows and correct provenance explicitly.
7. Update `updated_utc` and validate.

Required command:

```bash
PYTHONDONTWRITEBYTECODE=1 ../sammed3d-venv/bin/python scripts/verify_aflow_brats_leaderboard.py
```

If it fails, the research task is not complete.

## Mandatory result archival

After formal validation/test:

1. Save raw report and pre-access/selection receipt.
2. Recompute checkpoint/report/receipt/cache-index SHA-256.
3. Write `archive/research_records/<date>_<method>/RESULT.md` plus machine JSON.
4. Update `AFLOW_BRATS_HANDOFF_CURRENT.md` with outcome, metrics, access flags, failure boundary, and next decision.
5. Update `AFLOW_BRATS_METHOD_CATALOG.md` with plain result/interpretation.
6. If test ran, update both leaderboard files.
7. Run the method-catalog, leaderboard, and root-layout validators as applicable.

## Final response checklist

State in plain Chinese: idea and motivation; changed/fixed factors; best overall and single-model comparable results; cohort/metric/CI scope; training/inference/storage tradeoff; whether intuition was supported; test/outer/confirmation access; clickable current handoff, catalog, leaderboard, report, archive, and checkpoint.

Do not call a method “best” without naming cohort and overall-versus-single scope.


## 导师可读文档维护（2026-09-14用户要求）

根文档分工固定，不再将同一张长卡片复制到多个文件：

- `AFLOW_BRATS_WEEKLY_REPORT.md`是导师汇报：研究起点、核心优化、最终Dice、完成度与局限；重要结论改变时更新，通常控制在150行内。
- `AFLOW_BRATS_RESULTS.md`是从2026-08-13起的连续日期流水账。每次工作追加/更新对应日期，用“问题→做法→结果→决定”说明；明确仅文档或工程工作是否没有新精度结果。不得再让日期入口停在旧阶段。
- `AFLOW_BRATS_METHOD_CATALOG.md`保留通俗方法卡及最终状态：保留六个必要字段，短句说明直觉、唯一改动、固定项、结果、成本和下一步，链接标签用“核对材料”等可读名称。不直接显示长目录、哈希、PID、启动命令或多份收据。逐项细节可进入资料层，但负结果必须留有索引。
- `AFLOW_BRATS_HANDOFF_CURRENT.md`只写当前状态、数据角色、真实待办及禁止恢复的已关闭分支，通常控制在100行内；历史“运行中”不得累积在正文。
- `AFLOW_BRATS_LEADERBOARD.md/.json`保持精确分队列排名和证据约束，不为精简汇报删除旧排名。

新方法的七问、预注册、过程日志、完整参数、路径、哈希和raw结果仍放对应实验归档；正式结果需同步日期流水账和方法卡。禁止继续调用旧`publish_research_card.py`把完整技术卡自动前插到handoff和方法目录；它保留作历史重现，不再作为新文档发布入口。

历史完整根文档与来源索引见`archive/reviews/2026-09-14_mentor_facing_cleanup/EVIDENCE.md`。当前汇报不应把历史“当时纪录”写成“当前最好”；内部、开发、交互、外部及不同栅格必须明确区分。文档清理不改变数据访问历史或赋予新测试许可。


## 根目录技术材料约束（2026-09-14）

根目录JSON仅允许`AFLOW_BRATS_LEADERBOARD.json`，其他实验候选、清理收据、哈希清单必须放入相应archive目录；不得新建根目录临时JSON或SHA文件。历史根交接仅保留不超过20行的兼容导航页，全文放archive。

旧候选路径迁移见`archive/legacy_root_artifacts_20260914/README.md`。冻结脚本原文不改；旧默认根路径已失效，历史复现需显式提供归档候选和预注册参数，不得自动恢复关闭的实验。

文档整理或新增技术材料后，除原三个校验外，运行`PYTHONDONTWRITEBYTECODE=1 ../sammed3d-venv/bin/python scripts/verify_aflow_root_artifacts.py`，防止根目录重新堆积历史JSON和长交接。
